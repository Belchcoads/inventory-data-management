function notFound(req, res, next) {
  res.status(404).json({ success:false, message:`Route not found: ${req.originalUrl}` });
}
function errorHandler(err, req, res, next) {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({success:false,message:err.message});
  if (err.code === 11000) return res.status(409).json({success:false,message:'SKU already exists'});
  if (err.name === 'CastError') return res.status(400).json({success:false,message:'Invalid resource ID'});
  res.status(err.status || 500).json({success:false,message:err.message || 'Server error'});
}
module.exports = { notFound, errorHandler };
