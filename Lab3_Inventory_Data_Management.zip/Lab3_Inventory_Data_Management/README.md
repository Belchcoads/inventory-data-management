# Lab 3 – Inventory and Data Management System

REST API built with Node.js, Express, MongoDB and Mongoose, following the supplied Web Dev III Lab 3 requirements.

## Setup
1. Install Node.js and MongoDB Community Server.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `MONGO_URI`.
4. Run `npm run seed` to insert sample products.
5. Run `npm start`. API: `http://localhost:5000`.

## Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/products` | List with search, category filter, sorting and pagination |
| POST | `/api/products` | Create product |
| GET | `/api/products/:id` | Get one product |
| PUT | `/api/products/:id` | Update product |
| PATCH | `/api/products/:id/stock` | Safely adjust stock |
| DELETE | `/api/products/:id` | Delete product |
| GET | `/api/products/low-stock` | Low-stock report |
| GET | `/api/products/summary` | Category aggregation |

## Example requests
Create product:
```json
{"name":"Gel Pen Pack of 15","sku":"STNY-PN-713","category":"Stationery","price":120,"quantity":48,"reorderLevel":20,"supplier":"Cello Pens"}
```
Stock adjustment: `PATCH /api/products/PRODUCT_ID/stock`
```json
{"change":10}
```
List examples: `/api/products?category=Stationery&page=1&limit=5&sort=price&order=asc`

## Concepts
Mongoose schema validation, REST CRUD, query parameters, filtering, sorting, pagination, aggregation pipelines, indexes, middleware and centralized error handling.

Note: This is source code prepared to match the assignment brief. Run it in your environment and verify the database connection before submission.
