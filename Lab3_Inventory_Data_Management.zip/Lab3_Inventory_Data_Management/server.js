require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const connectDB = require('./config/db');
const productRoutes = require('./routes/productRoutes');
const {notFound,errorHandler} = require('./middleware/errorHandler');
const app = express();
app.use(express.json());
app.use(morgan('dev'));
app.get('/',(req,res)=>res.json({message:'Lab 3 Inventory API is running'}));
app.use('/api/products',productRoutes);
app.use(notFound);
app.use(errorHandler);
const PORT = process.env.PORT || 5000;
connectDB().then(()=>app.listen(PORT,()=>console.log(`Server running at http://localhost:${PORT}`)))
  .catch(err=>{console.error('Database connection failed:',err.message);process.exit(1);});
