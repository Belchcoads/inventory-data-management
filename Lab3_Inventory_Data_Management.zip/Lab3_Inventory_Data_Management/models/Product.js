const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  sku: { type: String, required: true, unique: true, uppercase: true, trim: true },
  category: { type: String, required: true, trim: true },
  price: { type: Number, required: true, min: 0 },
  quantity: { type: Number, required: true, min: 0, default: 0 },
  reorderLevel: { type: Number, min: 0, default: 10 },
  supplier: { type: String, default: 'Not specified' }
}, { timestamps: true });
productSchema.index({ category: 1, name: 1 });
productSchema.index({ quantity: 1, reorderLevel: 1 });
productSchema.virtual('stockValue').get(function(){ return this.price * this.quantity; });
productSchema.set('toJSON', { virtuals: true });
module.exports = mongoose.model('Product', productSchema);
