const express = require('express');
const Product = require('../models/Product');
const router = express.Router();

// GET /api/products?category=&search=&sort=price&order=asc&page=1&limit=10
router.get('/', async (req,res,next) => {
  try {
    const { category, search, sort='createdAt', order='desc' } = req.query;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const filter = {};
    if (category) filter.category = category;
    if (search) filter.$or = [{name:new RegExp(search,'i')},{sku:new RegExp(search,'i')}];
    const [products,total] = await Promise.all([
      Product.find(filter).sort({[sort]:order==='asc'?1:-1}).skip((page-1)*limit).limit(limit),
      Product.countDocuments(filter)
    ]);
    res.json({success:true,total,page,totalPages:Math.ceil(total/limit),products});
  } catch(e){next(e);}
});
router.post('/', async (req,res,next) => {
  try { const product = await Product.create(req.body); res.status(201).json({success:true,product}); }
  catch(e){next(e);}
});
router.get('/low-stock', async (req,res,next) => {
  try {
    const items = await Product.find({$expr:{$lte:['$quantity','$reorderLevel']}}).sort({quantity:1});
    res.json({success:true,count:items.length,lowStockItems:items});
  } catch(e){next(e);}
});
router.get('/summary', async (req,res,next) => {
  try {
    const summary = await Product.aggregate([
      {$group:{_id:'$category',totalItems:{$sum:1},totalQuantity:{$sum:'$quantity'},
        totalStockValue:{$sum:{$multiply:['$price','$quantity']}},averagePrice:{$avg:'$price'}}},
      {$sort:{_id:1}}
    ]);
    res.json({success:true,categories:summary.length,summary});
  } catch(e){next(e);}
});
router.get('/:id', async (req,res,next) => {
  try { const p=await Product.findById(req.params.id); if(!p)return res.status(404).json({success:false,message:'Product not found'}); res.json({success:true,product:p}); }
  catch(e){next(e);}
});
router.put('/:id', async (req,res,next) => {
  try { const p=await Product.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}); if(!p)return res.status(404).json({success:false,message:'Product not found'}); res.json({success:true,product:p}); }
  catch(e){next(e);}
});
router.patch('/:id/stock', async (req,res,next) => {
  try {
    const change=Number(req.body.change);
    if(!Number.isInteger(change)||change===0)return res.status(400).json({success:false,message:'change must be a non-zero integer'});
    const condition = change < 0 ? { _id:req.params.id, quantity:{$gte:Math.abs(change)} } : { _id:req.params.id };
    const p=await Product.findOneAndUpdate(condition,{$inc:{quantity:change}},{new:true,runValidators:true});
    if(!p)return res.status(400).json({success:false,message:'Product not found or insufficient stock'});
    res.json({success:true,message:'Stock updated',product:p});
  } catch(e){next(e);}
});
router.delete('/:id', async (req,res,next) => {
  try { const p=await Product.findByIdAndDelete(req.params.id); if(!p)return res.status(404).json({success:false,message:'Product not found'}); res.json({success:true,message:'Product deleted',id:p._id}); }
  catch(e){next(e);}
});
module.exports = router;
