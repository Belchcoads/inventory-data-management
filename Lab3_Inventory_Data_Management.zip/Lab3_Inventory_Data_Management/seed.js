require('dotenv').config();
const mongoose=require('mongoose');
const Product=require('./models/Product');
(async()=>{
 try {
  await mongoose.connect(process.env.MONGO_URI);
  await Product.deleteMany({});
  await Product.insertMany([
   {name:'Gel Pen Pack of 15',sku:'STNY-PN-713',category:'Stationery',price:120,quantity:48,reorderLevel:20,supplier:'Cello Pens'},
   {name:'Study Table',sku:'FURN-TB-812',category:'Furniture',price:3999,quantity:2,reorderLevel:4,supplier:'IKEA India'},
   {name:'Wireless Mouse',sku:'ELEC-MS-101',category:'Electronics',price:799,quantity:30,reorderLevel:8,supplier:'Tech Supply'},
   {name:'Notebook A4',sku:'STNY-NB-204',category:'Stationery',price:65,quantity:12,reorderLevel:15,supplier:'Classmate'}
  ]);
  console.log('Sample products inserted'); await mongoose.disconnect();
 } catch(e){console.error(e);process.exit(1);}
})();
